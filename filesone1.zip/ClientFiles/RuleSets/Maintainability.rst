<RULESET title="Maintainability" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6755687963</CREATED>
<MODIFIED>38447.6757541435</MODIFIED>
<COMMENTS>This rule set helps identify areas of your code that could become problems for someone else maintaining the code. These tips will also help you to avoid data loss and conflicts.</COMMENTS>
<RULESET_TOTAL>27</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <TYPE Type="1" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>

