<RULESET title="Writing SQL in PL/SQL" version="NeedToAdd">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38064.701991169</CREATED>
<MODIFIED>38071.6607594907</MODIFIED>
<COMMENTS>Rules in this set identify methods to improve the use  of SQL DML statements in your PL/SQL application.</COMMENTS>
<RULESET_TOTAL>21</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <CATEGORY cat="58" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>