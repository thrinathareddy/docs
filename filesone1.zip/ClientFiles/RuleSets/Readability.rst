<RULESET title="Readability" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6762668287</CREATED>
<MODIFIED>38447.6765959028</MODIFIED>
<COMMENTS>Rules in this category will help you identify areas in your code that violate generally accepted programming and readability criteria, or check for program consistency in naming and interface definition.</COMMENTS>
<RULESET_TOTAL>34</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <TYPE Type="3" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>

