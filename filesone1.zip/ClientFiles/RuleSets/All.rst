<RULESET title="All Rules" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.672953831</CREATED>
<MODIFIED>38447.673207338</MODIFIED>
<COMMENTS>This rule set tests your code against all rules in the Code Analysis universe including Code Correctness, Code Efficiency, Maintainability, Program Structure, and Readability.</COMMENTS>
<RULESET_TOTAL>154</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
<RULES>
<RULE rid="*"/>
</RULES>
</RULESET>
